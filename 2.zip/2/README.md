# 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/Yannik-Sommer/pen/ExqNaEj](https://codepen.io/Yannik-Sommer/pen/ExqNaEj).

